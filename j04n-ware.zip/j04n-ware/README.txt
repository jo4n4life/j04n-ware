WARNING!!!!

This program is meant to DESTROY your computer, The original
creator, "jo4n4life" is not responsible for ANY damages made
to the computer, This was meant to test out and just have fun
with it, not for malicious purposes.

Enjoy! :D